<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="page-frame">
<header class="nb-header">
  <a class="brand" href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img-logo.png'); ?>" alt="<?php bloginfo('name'); ?>" width="300" height="69" loading="eager" decoding="async"></a>
  <button class="menu" type="button" aria-label="Open menu" data-menu-toggle><span></span><span></span></button>
  <nav data-menu><?php if (has_nav_menu('primary')) { wp_nav_menu(['theme_location'=>'primary','container'=>false,'fallback_cb'=>false,'items_wrap'=>'%3$s']); } else { ?><a href="<?php echo esc_url(home_url('/programmes/')); ?>">Our Programs</a><a href="<?php echo esc_url(home_url('/store/')); ?>">Store</a><a href="<?php echo esc_url(home_url('/education/')); ?>">Education</a><?php } ?><a class="mobile-book" href="<?php echo esc_url(home_url('/consultation/')); ?>">Book Consultation</a></nav>
  <a class="book" href="<?php echo esc_url(home_url('/consultation/')); ?>">Book Consultation</a>
</header>