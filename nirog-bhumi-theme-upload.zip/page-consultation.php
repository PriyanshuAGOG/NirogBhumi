<?php
/**
 * Static Nirog Bhumi template generated from pages/consultation.html.
 */
get_header(); ?>
<main>
<section class="hero consultation-simple-hero">
  <div class="hero-copy consultation-hero-copy"><h1>Book Consultation</h1><div class="hero-actions"><a class="pill primary" href="#consultation-form">Book Consultation</a></div></div>
  <div class="consultation-hero-media"><figure class="hero-visual consultation-hero-visual consultation-photo-visual consultation-room-visual"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/consultation-hero-generated.jpg'); ?>" alt="Nirog Bhumi consultation session" width="1536" height="1024"></figure></div>
</section>
<section class="consultation-founder-strip">
  <div class="consultation-founder-copy"><p class="eyebrow">Founder-led session</p><h2>Book a 30-minute session with Gautam Khandelwal.</h2><p>Gautam brings over 26 years of personal practice, study, and lived experience in naturopathy and natural healing. This session is designed to understand your diabetes history, lifestyle rhythm, current medication context, and the most responsible next step before any program or product recommendation.</p></div>
  <figure><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/yoga-meditation-opt.jpg'); ?>" alt="Nirog Bhumi yoga and meditation practice" width="1100" height="733"></figure>
</section>
<section id="consultation-form" class="consultation-form-wrap">
  <div class="consultation-form-intro"><p class="eyebrow">Consultation form</p><h2>Share the details that matter.</h2><p>Step 1 is required so we can schedule and identify you correctly. The health details that follow are optional, but they help Gautam prepare for your 30-minute consultation.</p></div>
  <form class="consultation-booking-form step-consultation-form" data-step-form data-wp-form="true" method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" data-redirect="<?php echo esc_url(home_url('/consultation-payment/')); ?>"><input type="hidden" name="action" value="nirog_consultation_submit"><input type="hidden" name="consultation_entry_id" value=""><?php wp_nonce_field('nirog_consultation_submit', 'nirog_consultation_nonce'); ?>
    <div class="step-progress"><span data-step-count>Step 1 of 4</span><b></b></div>
    <fieldset data-step-panel><legend>Personal details</legend><div><label>Full name<input required name="name" autocomplete="name"></label><label>Email<input required type="email" name="email" autocomplete="email"></label><div class="international-phone"><label>Country code<input required name="country_code" value="+91" inputmode="tel" autocomplete="tel-country-code" pattern="\+[0-9]{1,4}" aria-label="Country calling code"></label><label>Phone / WhatsApp<input required name="phone" inputmode="tel" autocomplete="tel-national" pattern="[0-9 ()-]{6,20}"></label></div><label>Age<input required name="age" inputmode="numeric" autocomplete="bday"></label></div></fieldset>
    <fieldset data-step-panel hidden><legend>Health details</legend><div><label>Primary concern<select name="concern"><option>Type 2 diabetes</option><option>Pre-diabetes</option><option>Insulin resistance</option><option>Weight and sugar control</option><option>General consultation</option></select></label><label>Fasting blood sugar<input name="fasting" placeholder="Example: 145 mg/dL"></label><label>Post-meal blood sugar<input name="postmeal" placeholder="Example: 210 mg/dL"></label><label>Latest HbA1c<input name="hba1c" placeholder="Example: 8.2"></label><label>Blood pressure<input name="bp" placeholder="Example: 130/85"></label><label>Weight / waist<input name="body" placeholder="Example: 82 kg, 38 inch waist"></label></div></fieldset>
    <fieldset data-step-panel hidden><legend>Medication and lifestyle</legend><div><label>Current medication or insulin<textarea rows="4" name="medicines" placeholder="Medicine names, insulin, dose"></textarea></label><label>Other health conditions<textarea rows="4" name="conditions" placeholder="BP, thyroid, kidney, heart, digestion, pain, surgery, etc."></textarea></label><label>Food routine<textarea rows="4" name="food" placeholder="Meals, snacks, tea, late-night eating, eating window"></textarea></label><label>Sleep, stress and activity<textarea rows="4" name="lifestyle" placeholder="Wake & sleep time, stress level, walking, yoga, work hours"></textarea></label><label>Attach reports, if available<input type="file" name="reports[]" multiple accept=".pdf,.jpg,.jpeg,.png,.webp,.doc,.docx"></label><label>Main goal<textarea rows="4" name="goal" placeholder="What do you want help with first?"></textarea></label></div></fieldset>
    <fieldset data-step-panel hidden><legend>Consent</legend><div class="consent-copy"><p><strong>Consultation disclaimer:</strong> I understand that this 30-minute consultation is for educational and lifestyle guidance only. It is not emergency care, diagnosis, prescription, or a substitute for consultation with my treating physician. I will not start, stop, or change any medication based on this session without discussing it with my doctor.</p><p><strong>Data consent:</strong> I consent to Nirog Bhumi collecting and processing my personal and health-related information, including my name, contact details, diabetes history, lifestyle information, medication context, and any reports or information shared by me, for the purpose of scheduling and conducting this consultation, providing lifestyle guidance, maintaining consultation records, follow-up communication, and recommending suitable Nirog Bhumi programs or products where appropriate.</p><p>I understand that my information will be handled as per Nirog Bhumi's Privacy Policy, that I may request access, correction, or withdrawal of consent as permitted under applicable law, and that withdrawal of consent may affect Nirog Bhumi's ability to provide consultation or follow-up services.</p></div><label class="check"><input required type="checkbox" name="consultation_disclaimer"> I agree to the consultation disclaimer.</label><label class="check"><input required type="checkbox" name="data_processing_consent"> I consent to the processing of my personal and health-related data as described above.</label><label class="check"><input type="checkbox" name="followup_consent"> I agree to receive follow-up messages and program/product recommendations from Nirog Bhumi.</label></fieldset>
    <div class="step-actions"><button class="pill ghost" type="button" data-step-prev hidden>Back</button><button class="pill primary" type="button" data-step-next>Next</button><button class="pill primary" type="submit" hidden>Continue to Payment</button></div>
    <p data-form-status></p>
  </form>
</section><?php if (!empty($_GET['edit_consultation']) && !empty($_GET['entry'])) : ?><script>
document.addEventListener('DOMContentLoaded',function(){
  var form=document.querySelector('[data-step-form]');
  if(!form)return;
  var url=<?php echo wp_json_encode(add_query_arg(['action'=>'nirog_consultation_edit_data','entry'=>absint(wp_unslash($_GET['entry']))],admin_url('admin-ajax.php'))); ?>;
  fetch(url,{credentials:'same-origin',cache:'no-store'}).then(function(response){return response.json();}).then(function(result){
    if(!result.success)throw new Error(result.data&&result.data.message?result.data.message:'Unable to load the saved response.');
    Object.keys(result.data).forEach(function(name){
      var field=form.elements.namedItem(name);if(!field)return;
      if(field.type==='checkbox')field.checked=result.data[name]==='yes';else field.value=result.data[name]||'';
    });
    var status=form.querySelector('[data-form-status]');if(status)status.textContent='Your saved response is ready to edit. Submit again to update it.';
  }).catch(function(error){var status=form.querySelector('[data-form-status]');if(status)status.textContent=error.message;});
});
</script><?php endif; ?>
</main>
<?php get_footer(); ?>